#include<stdio.h>
#include <stdio.h>
#include <stdlib.h>//其中包含system函数
#include <conio.h>//定义了通过控制台进行 数据输入 和数据输出的函数，如getch函数。
#include <string.h>//定义字符数组
#include <math.h>
#include<time.h>
#define LEN sizeof(struct book)
struct date
{
	int fip[4],lip[4];  //起始及结束IP
	        //全部数据 
	char qy[8];     //区域
	char sf[8];     //省份
	char cs[8];    //城市
	char isp[8];   //ISP      //具体信息
	char dates[60];
	char date[100][60];
}date;                  //IP信息结构体

void mainmenu()                  //主菜单  (schoice) 
{
	system("cls");
	    printf ( "\n" );
		printf ( "\n" );
		printf ( "            	******************IP地址查询系统*************\n" );
		printf ( "	______________________________________________________________________________\n" );
		printf ( "	|---->                       请选择输入你要操作的选择                      <----|\n" );
		printf ( "	|----> 1：单个输入                                                        <----|\n" );
		printf ( "	|----> 2：范围输入                                                        <----|\n" );
		printf ( "	|----> 3：多输入                                                          <----|\n" );
		printf ( "	|----> 4：退出系统                                                        <----|\n" );
		printf ( "	|_____________________________________________________________________________|\n" );
		printf("请输入你的选择，按回车键确认\n");
	return ;
}
void lmain()              //输入选择函数界面
{

	mainmenu();
	char choose;
	void main1();
	void main2();
	void main3();
	scanf("%c",&choose);
	switch(choose)
	{
		case'1':
		main1();
		break;
		case'2':
		main2();
		break;
		case'3':
		main3();
		break;
		case'4':
	  		system("cls");
	  	getch();
  		exit(0);
  		system ("cls");
		break;
	}
}
void pchoice()          //输出函数界面
{
	    printf ( "\n" );
		printf ( "\n" );
		printf ( "            	******************输出方式选择*************\n" );
		printf ( "	______________________________________________________________________________\n" );
		printf ( "	|---->                       请选择输入你要操作的选择                      <----|\n" );
		printf ( "	|----> 1：显示国家                                                        <----|\n" );
		printf ( "	|----> 2：显示区域                                                        <----|\n" );
		printf ( "	|----> 3：显示省份                                                        <----|\n" );
		printf ( "	|----> 4：显示城市                                                        <----|\n" );
		printf ( "	|----> 5：显示ISP                                                         <----|\n" );
		printf ( "	|----> 6：全部显示                                                        <----|\n" );
		printf ( "	|---->                      请用空格间隔开各个选项                         <----|\n" );
		printf ( "	|_____________________________________________________________________________|\n" );
		printf("请输入你的选择，按回车键确认\n");
		printf("不需要使用空格间隔开各个选项\n");
}



void main1()                //单输入主函数
{
	double TheTimes;
	clock_t start,finish;
	char a[5]; //a为存储选项的数组
	int main();               
	int i,n,ip[4]={-1},count=0;           //ip 为需要查询的IP
	printf("请输入要查询的ip地址\n");
	scanf("%d.%d.%d.%d",&ip[1],&ip[2],&ip[3],&ip[4]);
	//printf("%d %d %d %d\n",ip[1],ip[2],ip[3],ip[4]);
	if(ip[1]>255||ip[2]>255||ip[3]>255||ip[4]>255||ip[1]==-1||ip[2]==-1||ip[3]==-1||ip[1]==-1)
	{
		printf("---->输入有误，请按回车并重新输入<----");
		getchar();
		main1();
	}
	
	FILE *fp;
	fp=fopen("ip.txt","r");
	if(fp==NULL) 
	{
		printf("Error\n");
		
	}
	else
	{ 
		int flag=0;
		start=clock();
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
			//printf("%s\n",date.dates);
            if(ip[1]>date.fip[1]&&ip[1]<date.lip[1])
            flag=1;
            else if(ip[1]==date.fip[1]||ip[1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(ip[2]>date.fip[2]&&ip[2]<date.lip[2])
                    flag=1;
                    else if(ip[2]==date.fip[2]||ip[2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(ip[3]>date.fip[3]&&ip[3]<date.lip[3])
                            flag=1;
                            else if(ip[3]==date.fip[3]||ip[3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(ip[4]>=date.fip[4]&&ip[4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(ip[3]==date.fip[3])
                                    {
                                        if(ip[4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(ip[3]==date.lip[3])
                                    {
                                        if(ip[4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(ip[2]==date.fip[2])
                            {
                                if(ip[3]>date.fip[3])
                                flag=1;
                                else if(ip[3]==date.fip[3])
                                {
                                    if(ip[4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(ip[2]==date.lip[2])
                            {
                                if(ip[3]<date.lip[3])
                                flag=1;
                                else if(ip[3]==date.lip[3])
                                {
                                    if(ip[4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(ip[1]==date.fip[1])
                    {
                        if(ip[2]>date.fip[2])
                        flag=1;
                        else if(ip[2]==date.fip[2])
                        {
                            if(ip[3]>date.fip[3])
                            flag=1;
                            else if(ip[3]==date.fip[3])
                            {
                                if(ip[4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(ip[2]<date.lip[2])
                        flag=1;
                        else if(ip[2]==date.lip[2])
                        {
                            if(ip[3]<date.lip[3])
                            flag=1;
                            else if(ip[3]==date.lip[3])
                            {
                                if(ip[4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}
	} 
	pchoice();
	finish=clock();
	TheTimes=(double)(finish-start)/CLOCKS_PER_SEC;
	scanf("%s",a);
    
	n=strlen(a);
	int num;
	for(num=0;num<n;num++)
	{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
		
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
	}
	
	printf("\nwest time:%f",TheTimes);
	printf("\n按任意键按返回主菜单\n");
	getchar();
	getchar(); 
	system("cls");
	main();
}
void main2()                //范围输入主函数
{
	clock_t start,finish;
    double TheTimes;
	int fip[4]={-1},lip[4]={-1};             //输入范围的起始和终止
	int mid[4];                              //过渡数组，存储结尾ip
	char a[6];
	int main();
	int i,n,count,sum;
	printf("请输入要查询的ip地址\n");
	scanf("%d.%d.%d.%d-%d.%d.%d.%d",&fip[1],&fip[2],&fip[3],&fip[4],&lip[1],&lip[2],&lip[3],&lip[4]);
	if(fip[1]>255||fip[2]>255||fip[3]>255||fip[4]>255||fip[1]==-1||fip[2]==-1||fip[3]==-1||fip[1]==-1||lip[1]>255||lip[2]>255||lip[3]>255||lip[4]>255||lip[1]==-1||lip[2]==-1||lip[3]==-1||lip[1]==-1)
	{
		printf("---->输入有误，请按回车并重新输入<----");
		getchar();
		main2();
	}
	else
	{
		FILE *fp;
		fp=fopen("ip.txt","r");
		int flag=0;
		start=clock();
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
			//printf("%s\n",date.dates);
            if(lip[1]>date.fip[1]&&lip[1]<date.lip[1])
            flag=1;
            else if(lip[1]==date.fip[1]||lip[1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(lip[2]>date.fip[2]&&lip[2]<date.lip[2])
                    flag=1;
                    else if(lip[2]==date.fip[2]||lip[2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(lip[3]>date.fip[3]&&lip[3]<date.lip[3])
                            flag=1;
                            else if(lip[3]==date.fip[3]||lip[3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(lip[4]>=date.fip[4]&&lip[4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(lip[3]==date.fip[3])
                                    {
                                        if(lip[4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(lip[3]==date.lip[3])
                                    {
                                        if(lip[4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(lip[2]==date.fip[2])
                            {
                                if(lip[3]>date.fip[3])
                                flag=1;
                                else if(lip[3]==date.fip[3])
                                {
                                    if(lip[4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(lip[2]==date.lip[2])
                            {
                                if(lip[3]<date.lip[3])
                                flag=1;
                                else if(lip[3]==date.lip[3])
                                {
                                    if(lip[4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(lip[1]==date.fip[1])
                    {
                        if(lip[2]>date.fip[2])
                        flag=1;
                        else if(lip[2]==date.fip[2])
                        {
                            if(lip[3]>date.fip[3])
                            flag=1;
                            else if(lip[3]==date.fip[3])
                            {
                                if(lip[4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(lip[2]<date.lip[2])
                        flag=1;
                        else if(lip[2]==date.lip[2])
                        {
                            if(lip[3]<date.lip[3])
                            flag=1;
                            else if(lip[3]==date.lip[3])
                            {
                                if(lip[4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}
		mid[1]=date.fip[1];
		mid[2]=date.fip[2];
		mid[3]=date.fip[3];
		mid[4]=date.fip[4];
		//printf("%d %d %d %d",mid[1],mid[2],mid[3],mid[4]);
		fclose(fp);
	}
	FILE *fp;
	fp=fopen("ip.txt","r");
	if(fp==NULL) 
	{
		printf("Error\n");
		
	}
	else
	{ 
		int flag=0;
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
			//printf("%s\n",date.dates);
            if(fip[1]>date.fip[1]&&fip[1]<date.lip[1])
            flag=1;
            else if(fip[1]==date.fip[1]||fip[1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(fip[2]>date.fip[2]&&fip[2]<date.lip[2])
                    flag=1;
                    else if(fip[2]==date.fip[2]||fip[2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(fip[3]>date.fip[3]&&fip[3]<date.lip[3])
                            flag=1;
                            else if(fip[3]==date.fip[3]||fip[3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(fip[4]>=date.fip[4]&&fip[4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(fip[3]==date.fip[3])
                                    {
                                        if(fip[4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(fip[3]==date.lip[3])
                                    {
                                        if(fip[4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(fip[2]==date.fip[2])
                            {
                                if(fip[3]>date.fip[3])
                                flag=1;
                                else if(fip[3]==date.fip[3])
                                {
                                    if(fip[4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(fip[2]==date.lip[2])
                            {
                                if(fip[3]<date.lip[3])
                                flag=1;
                                else if(fip[3]==date.lip[3])
                                {
                                    if(fip[4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(fip[1]==date.fip[1])
                    {
                        if(fip[2]>date.fip[2])
                        flag=1;
                        else if(fip[2]==date.fip[2])
                        {
                            if(fip[3]>date.fip[3])
                            flag=1;
                            else if(fip[3]==date.fip[3])
                            {
                                if(fip[4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(fip[2]<date.lip[2])
                        flag=1;
                        else if(fip[2]==date.lip[2])
                        {
                            if(fip[3]<date.lip[3])
                            flag=1;
                            else if(fip[3]==date.lip[3])
                            {
                                if(fip[4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}
		finish=clock();
		pchoice();
		scanf("%s",a);          //输出选项
		n=strlen(a);
		printf("输出结果：\n");
		
		if(date.fip[1]==mid[1]&&date.fip[2]==mid[2]&&date.fip[3]==mid[3]&&date.fip[4]==mid[4])
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",fip[1],fip[2],fip[3],fip[4],lip[1],lip[2],lip[3],lip[4]);
			int num;
			for(num=0;num<n;num++)
		{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
		printf("\n");
		}
		else
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",fip[1],fip[2],fip[3],fip[4],date.lip[1],date.lip[2],date.lip[3],date.lip[4]);
		//printf("%s\n",date.dates);
		int num;
		for(num=0;num<n;num++)
		{ 
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
		while(date.fip[1]!=mid[1]||date.fip[2]!=mid[2]||date.fip[3]!=mid[3]||date.fip[4]!=mid[4])
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",date.fip[1],date.fip[2],date.fip[3],date.fip[4],date.lip[1],date.lip[2],date.lip[3],date.lip[4]);
	for(num=0;num<n;num++)
	{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
	}
			printf("\n");
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
		}
		printf("%d.%d.%d.%d-%d.%d.%d.%d：",date.fip[1],date.fip[2],date.fip[3],date.fip[4],lip[1],lip[2],lip[3],lip[4]);
		for(num=0;num<n;num++)
		{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
		}
	}
	TheTimes=(double)(finish-start)/CLOCKS_PER_SEC;
	printf("\nwest time:%f s",TheTimes);
	printf("\n按回车键按返回主菜单\n");
	getchar();
	getchar();
	system("cls");
	main();
}
void main3()                //多输入主函数
{
	clock_t start,finish;
    double TheTimes;	
	printf("1.多个a\n");
	printf("2.多个b\n");
	printf("请输入您的选项\n");
	int a;
	scanf("%d",&a);
if(a==1)
{
	clock_t start,finish;
    double TheTimes;
	int main();
	void pchoice();
	char a[6];
	int n;
	printf("请输入要查询的ip地址（多条查询，每条之间需用空格间隔）\n");
	//printf("例子：1.1.1.1\n");
	int ip[60][4],i,sum;       //ip为需要查询的IP
	char x='\0';
	for(i=1;x!='\n';i++)
	{
		scanf("%d.%d.%d.%d",&ip[i][1],&ip[i][2],&ip[i][3],&ip[i][4]);
		if(ip[i][1]>255||ip[i][2]>255||ip[i][3]>255||ip[i][4]>255||ip[i][1]==-1||ip[i][2]==-1||ip[i][3]==-1||ip[i][1]==-1)
		{
			printf("---->输入有误，请按回车并重新输入<----");
			getchar();
			scanf("%d.%d.%d.%d",&ip[i][1],&ip[i][2],&ip[i][3],&ip[i][4]);
		}
		x=getchar();
	}
	sum=i-1;
	FILE *fp; 
	fp=fopen("ip.txt","r");
    start=clock();
	for(i=1;i<=sum;i++)
	{
		
		int flag=0;
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.date[i]);
			//printf("%s\n",date.dates);
            if(ip[i][1]>date.fip[1]&&ip[i][1]<date.lip[1])
            flag=1;
            else if(ip[i][1]==date.fip[1]||ip[i][1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(ip[i][2]>date.fip[2]&&ip[i][2]<date.lip[2])
                    flag=1;
                    else if(ip[i][2]==date.fip[2]||ip[i][2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(ip[i][3]>date.fip[3]&&ip[i][3]<date.lip[3])
                            flag=1;
                            else if(ip[i][3]==date.fip[3]||ip[i][3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(ip[i][4]>=date.fip[4]&&ip[i][4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(ip[i][3]==date.fip[3])
                                    {
                                        if(ip[i][4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(ip[i][3]==date.lip[3])
                                    {
                                        if(ip[i][4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(ip[i][2]==date.fip[2])
                            {
                                if(ip[i][3]>date.fip[3])
                                flag=1;
                                else if(ip[i][3]==date.fip[3])
                                {
                                    if(ip[i][4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(ip[i][2]==date.lip[2])
                            {
                                if(ip[i][3]<date.lip[3])
                                flag=1;
                                else if(ip[i][3]==date.lip[3])
                                {
                                    if(ip[i][4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(ip[i][1]==date.fip[1])
                    {
                        if(ip[i][2]>date.fip[2])
                        flag=1;
                        else if(ip[i][2]==date.fip[2])
                        {
                            if(ip[i][3]>date.fip[3])
                            flag=1;
                            else if(ip[i][3]==date.fip[3])
                            {
                                if(ip[i][4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(ip[i][2]<date.lip[2])
                        flag=1;
                        else if(ip[i][2]==date.lip[2])
                        {
                            if(ip[i][3]<date.lip[3])
                            flag=1;
                            else if(ip[i][3]==date.lip[3])
                            {
                                if(ip[i][4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}

	}
	finish=clock();
	pchoice();
	scanf("%s",a);
	n=strlen(a);
	
	int num,count,j; 
	for(j=1;j<=sum;j++)
	{
	printf("IP：%d.%d.%d.%d\n",ip[j][1],ip[j][2],ip[j][3],ip[j][4]);
	for(num=0;num<n;num++)
	{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.date[j][i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.date[j][i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.date[j][i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.date[j][i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.date[j][i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.date[j][i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.date[j][i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.date[j][i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.date[j][i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.date[j][i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.date[j][i]!='\0';i++)
			{
				if(date.date[j][i]=='|')
				{
					count++;
					printf(" ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.date[j][i]);
				}

			}
		}
	}
	printf("\n");
	}
	TheTimes=(double)(finish-start)/CLOCKS_PER_SEC;
	printf("\nwest time:%f s",TheTimes);
	printf("\n按回车键按返回主菜单\n");
	getchar();
	getchar();
	//system("pause");
	system("cls");
	main();
}
else if(a==2)
{
	clock_t start,finish;
    double TheTimes,Times=0;
	int ffip[60][4],llip[60][4],i;
	char x;
	int main();
	printf("请输入要查询的ip地址（多条查询，每条之间需用空格间隔）\n");
	for(i=1;x!='\n';i++)
	{
		scanf("%d.%d.%d.%d-%d.%d.%d.%d",&ffip[i][1],&ffip[i][2],&ffip[i][3],&ffip[i][4],&llip[i][1],&llip[i][2],&llip[i][3],&llip[i][4]);
		x=getchar();
	}

	int q,ex;
	int fip[4],lip[4];
	ex=i;
	int n;
	
	pchoice();
	printf("输出选项需多次输入\n");
	
	for(q=1;q<ex;q++)
	{
		for(i=1;i<=4;i++)
		{
			fip[i]=ffip[q][i];
			lip[i]=llip[q][i];
		}

	int mid[4];                              //过渡数组，存储结尾ip
	
	
	int count;
	//scanf("%d.%d.%d.%d-%d.%d.%d.%d",&fip[1],&fip[2],&fip[3],&fip[4],&lip[1],&lip[2],&lip[3],&lip[4]);
	if(fip[1]>255||fip[2]>255||fip[3]>255||fip[4]>255||fip[1]==-1||fip[2]==-1||fip[3]==-1||fip[1]==-1||lip[1]>255||lip[2]>255||lip[3]>255||lip[4]>255||lip[1]==-1||lip[2]==-1||lip[3]==-1||lip[1]==-1)
	{
		printf("---->输入有误，请按回车并重新输入<----");
		getchar();
		main2();
	}
	else
	{

		FILE *fp;
		fp=fopen("ip.txt","r");
		int flag=0;
		start=clock();
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
			//printf("%s\n",date.dates);
            if(lip[1]>date.fip[1]&&lip[1]<date.lip[1])
            flag=1;
            else if(lip[1]==date.fip[1]||lip[1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(lip[2]>date.fip[2]&&lip[2]<date.lip[2])
                    flag=1;
                    else if(lip[2]==date.fip[2]||lip[2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(lip[3]>date.fip[3]&&lip[3]<date.lip[3])
                            flag=1;
                            else if(lip[3]==date.fip[3]||lip[3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(lip[4]>=date.fip[4]&&lip[4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(lip[3]==date.fip[3])
                                    {
                                        if(lip[4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(lip[3]==date.lip[3])
                                    {
                                        if(lip[4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(lip[2]==date.fip[2])
                            {
                                if(lip[3]>date.fip[3])
                                flag=1;
                                else if(lip[3]==date.fip[3])
                                {
                                    if(lip[4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(lip[2]==date.lip[2])
                            {
                                if(lip[3]<date.lip[3])
                                flag=1;
                                else if(lip[3]==date.lip[3])
                                {
                                    if(lip[4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(lip[1]==date.fip[1])
                    {
                        if(lip[2]>date.fip[2])
                        flag=1;
                        else if(lip[2]==date.fip[2])
                        {
                            if(lip[3]>date.fip[3])
                            flag=1;
                            else if(lip[3]==date.fip[3])
                            {
                                if(lip[4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(lip[2]<date.lip[2])
                        flag=1;
                        else if(lip[2]==date.lip[2])
                        {
                            if(lip[3]<date.lip[3])
                            flag=1;
                            else if(lip[3]==date.lip[3])
                            {
                                if(lip[4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}
		mid[1]=date.fip[1];
		mid[2]=date.fip[2];
		mid[3]=date.fip[3];
		mid[4]=date.fip[4];
		//printf("%d %d %d %d",mid[1],mid[2],mid[3],mid[4]);
		fclose(fp);
	}
	FILE *fp;
	fp=fopen("ip.txt","r");
	if(fp==NULL) 
	{
		printf("Error\n");
		
	}
	else
	{ 
		int flag=0;
		while(flag!=1)
		{
            flag=0;
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
			//printf("%s\n",date.dates);
            if(fip[1]>date.fip[1]&&fip[1]<date.lip[1])
            flag=1;
            else if(fip[1]==date.fip[1]||fip[1]==date.lip[1])
            {
                if(date.fip[1]==date.lip[1])
                {
                    if(fip[2]>date.fip[2]&&fip[2]<date.lip[2])
                    flag=1;
                    else if(fip[2]==date.fip[2]||fip[2]==date.lip[2])
                    {
                        if(date.fip[2]==date.lip[2])
                        {
                            if(fip[3]>date.fip[3]&&fip[3]<date.lip[3])
                            flag=1;
                            else if(fip[3]==date.fip[3]||fip[3]==date.lip[3])
                            {
                                if(date.fip[3]==date.lip[3])
                                {
                                    if(fip[4]>=date.fip[4]&&fip[4]<=date.lip[4])
                                    flag=1;
                                }
                                else
                                {
                                    if(fip[3]==date.fip[3])
                                    {
                                        if(fip[4]>=date.fip[4])
                                        flag=1;
                                    }
                                    else if(fip[3]==date.lip[3])
                                    {
                                        if(fip[4]<=date.lip[4])
                                        flag=1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(fip[2]==date.fip[2])
                            {
                                if(fip[3]>date.fip[3])
                                flag=1;
                                else if(fip[3]==date.fip[3])
                                {
                                    if(fip[4]>=date.fip[4])
                                    flag=1;
                                }
                            }
                            else if(fip[2]==date.lip[2])
                            {
                                if(fip[3]<date.lip[3])
                                flag=1;
                                else if(fip[3]==date.lip[3])
                                {
                                    if(fip[4]<=date.lip[4])
                                    flag=1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(fip[1]==date.fip[1])
                    {
                        if(fip[2]>date.fip[2])
                        flag=1;
                        else if(fip[2]==date.fip[2])
                        {
                            if(fip[3]>date.fip[3])
                            flag=1;
                            else if(fip[3]==date.fip[3])
                            {
                                if(fip[4]>=date.fip[4])
                                flag=1;
                            }
                        }
                    }
                    else
                    {
                        if(fip[2]<date.lip[2])
                        flag=1;
                        else if(fip[2]==date.lip[2])
                        {
                            if(fip[3]<date.lip[3])
                            flag=1;
                            else if(fip[3]==date.lip[3])
                            {
                                if(fip[4]<=date.lip[4])
                                flag=1;
                            }
                        }
                    }
                }
            }
		}
		finish=clock();
		TheTimes=(double)(finish-start)/CLOCKS_PER_SEC;
		Times+=TheTimes;
		char a[7];
		scanf("%s",a);          //输出选项
		n=strlen(a);
		if(date.fip[1]==mid[1]&&date.fip[2]==mid[2]&&date.fip[3]==mid[3]&&date.fip[4]==mid[4])
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",fip[1],fip[2],fip[3],fip[4],lip[1],lip[2],lip[3],lip[4]);
			int num;
			for(num=0;num<n;num++)
		{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
		printf("\n");
		}
		else
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",fip[1],fip[2],fip[3],fip[4],date.lip[1],date.lip[2],date.lip[3],date.lip[4]);
		//printf("%s\n",date.dates);
		int num;
		for(num=0;num<n;num++)
		{ 
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
		while(date.fip[1]!=mid[1]||date.fip[2]!=mid[2]||date.fip[3]!=mid[3]||date.fip[4]!=mid[4])
		{
			printf("%d.%d.%d.%d-%d.%d.%d.%d：",date.fip[1],date.fip[2],date.fip[3],date.fip[4],date.lip[1],date.lip[2],date.lip[3],date.lip[4]);
	for(num=0;num<n;num++)
	{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
	}
			printf("\n");
			fscanf(fp,"%d.%d.%d.%d|%d.%d.%d.%d|%s",&date.fip[1],&date.fip[2],&date.fip[3],&date.fip[4],&date.lip[1],&date.lip[2],&date.lip[3],&date.lip[4],date.dates);
		}
		printf("%d.%d.%d.%d-%d.%d.%d.%d：",date.fip[1],date.fip[2],date.fip[3],date.fip[4],lip[1],lip[2],lip[3],lip[4]);
		for(num=0;num<n;num++)
		{
		if(a[num]=='1')
		{
			count=0;
			printf("国家：");
			for(i=0;count!=1;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==0)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='2')
		{
			count=0;
			printf("区域：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='3')
		{
			count=0;
			printf("省份：");
			for(i=0;count!=3;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==2)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='4')
		{
			count=0;
			printf("城市：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='5')
		{
			count=0;
			printf("ISP：");
			for(i=0;count!=2;i++)
			{
				if(date.dates[i]=='|')
					count++;
				else
				{
					if(count==1)
					printf("%c",date.dates[i]);
				}

			}
			printf("\n");
		}
		if(a[num]=='6')
		{
			count=0;
			printf("国家：");
			for(i=0;date.dates[i]!='\0';i++)
			{
				if(date.dates[i]=='|')
				{
					count++;
					printf("  ");
					if(count==1)
						printf("区域：");
					if(count==2)
						printf("省份：");
					if(count==3)
						printf("城市：");
					if(count==4)
						printf("ISP：");

				}
				else
				{
				printf("%c",date.dates[i]);
				}

			}
		}
		}
		}
	}
	printf("\n");
	}
	printf("\nwest time:%f s",TheTimes);
	printf("\n请按任意键返回\n");
	getchar();
	getchar();
	main();
}
else
{
	printf("输入有误，按回车重新输入 \n");
	system("cls");
	main3();
}
}
int main()
{
	system("color 3F");
	lmain();
	
}